import numpy as np
import torch
import torch.nn as nn
from torch.autograd import Variable
import math
import torch.nn.functional as F
from torch.autograd import grad


def radiation_noise(data, alpha_range=(0.9, 1.1), beta=0.04): # Pavia/Houston = 0.04
    alpha = torch.empty(1).uniform_(*alpha_range).item()  # 在 CUDA 上生成随机数
    noise = torch.randn_like(data)  # 与 data 形状一致的噪声张量
    x = alpha * data + beta * noise
    return x

def flip_augmentation(data):
    # data 是一个 CUDA Tensor，支持维度 shape: (7, 7, 103) 或 (7, 7)
    horizontal = torch.rand(1).item() > 0.5  # 随机布尔值
    vertical = torch.rand(1).item() > 0.5
    # rot = torch.rand(1).item() > 0.5

    # if horizontal:
    #     data = torch.flip(data, dims=[1])  # 水平翻转
    # if vertical:
    #     data = torch.flip(data, dims=[0])  # 垂直翻转
    # if rot:
        # data = torch.rot90(data, k=1, dims=[-1, -2]) #旋转
    if horizontal:
        data = torch.flip(data, dims=[-1])  # 水平翻转
    if vertical:
        data = torch.flip(data, dims=[-2])  # 垂直翻转


    return data

def Mixup(x1, x2,  alpa = 0.9):

    # center_pixel_data = x[:,1,1,:].clone()
    # x1 = x1[: : -1]
    mix = torch.tensor(np.random.beta(alpa, alpa)).float()
    mix = np.maximum(mix, 1 - mix)
    x1 = x1.flip(0)
    xmix = x1 * mix + x2 * (1 - mix)
    # xmix[:,3,3,:] = center_pixel_data
    #     lmix = l * mix[:, :, 0, 0] + l[::-1] * (1 - mix[:, :, 0, 0])
    return xmix

if __name__ == '__main__':
    x = tensor = torch.randint(0, 10, (8, 5))
    print(x)

    x_rev = x.flip(0)
    print(x_rev)


